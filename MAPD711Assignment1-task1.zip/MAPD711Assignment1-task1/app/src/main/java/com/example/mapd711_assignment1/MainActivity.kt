package com.example.mapd711_assignment1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editName=findViewById<EditText>(R.id.name_task1)
        val editAddress=findViewById<EditText>(R.id.address_task1)
        val editProf=findViewById<EditText>(R.id.profession_task1)
        val editDream=findViewById<EditText>(R.id.dream_job)
        val editFav=findViewById<EditText>(R.id.favourite_food)
        val btn=findViewById<Button>(R.id.btnSubmit)

        btn.setOnClickListener() {

            Intent(this, SecondActivity::class.java).also {
                it.putExtra("name", editName.text.toString())
                it.putExtra("address", editAddress.text.toString())
                it.putExtra("prof", editProf.text.toString())
                it.putExtra("dream", editDream.text.toString())
                it.putExtra("fav", editFav.text.toString())
                startActivity(it)
            }
        }
    }
}