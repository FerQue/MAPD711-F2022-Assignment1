package com.example.mapd711_assignment1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)


        val textName = findViewById<TextView>(R.id.text_name)
        val textAddress = findViewById<TextView>(R.id.text_address)
        val textProfession = findViewById<TextView>(R.id.text_profession)
        val textJob = findViewById<TextView>(R.id.text_dream_job)
        val textFood = findViewById<TextView>(R.id.text_fav_food)

        val name = intent.getStringExtra("name")
        val address = intent.getStringExtra("address")
        val profession = intent.getStringExtra("prof")
        val dreamJob = intent.getStringExtra("dream")
        val favouriteFood = intent.getStringExtra("fav")

        textName.text = name
        textAddress.text = address
        textProfession.text = profession
        textJob.text = dreamJob
        textFood.text = favouriteFood

    }
}