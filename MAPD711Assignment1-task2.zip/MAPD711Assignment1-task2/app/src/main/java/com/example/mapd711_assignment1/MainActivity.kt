package com.example.mapd711_assignment1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn = findViewById<Button>(R.id.btnSubmit)

        btn.setOnClickListener() {

            Intent(this, SecondActivity::class.java).also {
                it.putExtra("name", getString(R.string.my_name))
                it.putExtra("address", getString(R.string.my_address))
                it.putExtra("prof", getString(R.string.my_prof))
                it.putExtra("dream", getString(R.string.dream_job))
                it.putExtra("fav", getString(R.string.fav_foods))
                startActivity(it)
            }
        }
    }
}